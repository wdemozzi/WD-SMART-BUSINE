# WD Smart Business — Frontend

React + TypeScript + Tailwind CSS v4 + Supabase. Estrutura pronta para os módulos do sistema, com autenticação, layout do dashboard e controle de acesso por papel (`super_admin`, `admin_empresa`, `funcionario`, `cliente_final`).

## Como rodar

```bash
npm install
cp .env.example .env      # preencha com a URL e a anon key do seu projeto Supabase
npm run dev
```

Acesse `http://localhost:5173`. Sem sessão, você é redirecionado para `/login`.

## Estrutura

```
src/
├── components/
│   ├── ui/            # Botão, Card, StatusBadge (estilo shadcn, escritos à mão)
│   ├── layout/         # Sidebar, Topbar, AppLayout, ProtectedRoute
│   └── dashboard/      # Componentes específicos do dashboard (MetricCard)
├── context/
│   └── AuthContext.tsx # Sessão Supabase + perfil + empresa atual
├── lib/
│   ├── supabase.ts     # Cliente Supabase
│   └── utils.ts        # cn(), formatCurrency(), formatDate()
├── pages/
│   ├── auth/login.tsx
│   ├── dashboard/       # Cards de métrica + gráfico de receita (dados reais das views SQL)
│   ├── clientes/         # Listagem de clientes (CRM)
│   ├── agendamentos/, financeiro/, whatsapp/, ia/, configuracoes/  # placeholders prontos para receber os módulos
│   └── super-admin/empresas.tsx
└── types/database.ts    # Tipos alinhados ao schema SQL (substituir por `supabase gen types`)
```

## Sistema de design

- **Cor primária**: índigo `#4F46E5` — não usa o cinza/terracota "padrão de IA".
- **Tipografia**: Inter (UI), Space Grotesk (títulos), JetBrains Mono (números e métricas — classe `.font-data`).
- **Tokens**: definidos em `src/index.css` via `@theme` do Tailwind v4. Dark mode via classe `.dark` na raiz (alternada pelo botão na Topbar).
- **StatusBadge**: componente central que padroniza a cor de cada status (`agendado`, `confirmado`, `pago`, etc.) em todo o sistema — é o elemento de assinatura visual do produto.

## Próximos passos sugeridos

1. Gerar tipos reais do banco: `supabase gen types typescript --project-id SEU_ID > src/types/database.ts`.
2. Construir o calendário completo em `/agendamentos` (dia/semana/mês) consumindo a tabela `agendamentos`.
3. Construir a página pública de agendamento online (`/agendar/:slug-da-empresa`), fora do layout autenticado.
4. Implementar upload de documentos + status de processamento em `/ia`.
5. Adicionar code-splitting por rota (`React.lazy`) — o bundle já está no limiar de aviso do Vite.
