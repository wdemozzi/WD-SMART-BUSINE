import { Navigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import type { UserRole } from '@/types/database'

export function ProtectedRoute({
  children,
  papeisPermitidos,
}: {
  children: React.ReactNode
  papeisPermitidos?: UserRole[]
}) {
  const { session, perfil, carregando } = useAuth()

  if (carregando) {
    return (
      <div className="flex h-screen items-center justify-center text-sm text-[var(--color-ink-400)]">
        Carregando…
      </div>
    )
  }

  if (!session) return <Navigate to="/login" replace />

  if (papeisPermitidos && perfil && !papeisPermitidos.includes(perfil.role)) {
    return <Navigate to="/dashboard" replace />
  }

  return <>{children}</>
}
