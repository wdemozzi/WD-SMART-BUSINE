import { useEffect, useRef, useState, type FormEvent } from 'react'
import { Upload, Copy, Check } from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import { useEmpresaAtual, segmentos } from '@/hooks/use-empresa-atual'
import { supabase } from '@/lib/supabase'
import { Label, Input, Select } from '@/components/ui/form'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import type { EmpresaFormValues } from '@/hooks/use-empresa-atual'

export function AbaDadosEmpresa() {
  const { empresa } = useAuth()
  const { valores, carregando, erro, salvar } = useEmpresaAtual(empresa?.id)
  const [form, setForm] = useState<EmpresaFormValues | null>(null)
  const [salvando, setSalvando] = useState(false)
  const [sucesso, setSucesso] = useState(false)
  const [linkCopiado, setLinkCopiado] = useState(false)
  const [enviandoLogo, setEnviandoLogo] = useState(false)
  const [erroLogo, setErroLogo] = useState<string | null>(null)
  const inputArquivoRef = useRef<HTMLInputElement>(null)

  const linkAgendamento = empresa?.slug ? `${window.location.origin}/agendar/${empresa.slug}` : null

  function copiarLink() {
    if (!linkAgendamento) return
    navigator.clipboard.writeText(linkAgendamento)
    setLinkCopiado(true)
    setTimeout(() => setLinkCopiado(false), 2000)
  }

  async function handleUploadLogo(e: React.ChangeEvent<HTMLInputElement>) {
    const arquivo = e.target.files?.[0]
    if (!arquivo || !empresa?.id || !form) return

    if (arquivo.size > 2 * 1024 * 1024) {
      setErroLogo('A imagem precisa ter no máximo 2MB.')
      return
    }

    setEnviandoLogo(true)
    setErroLogo(null)

    const extensao = arquivo.name.split('.').pop()
    const caminho = `${empresa.id}/logo.${extensao}`

    const { error: erroUpload } = await supabase.storage
      .from('logos')
      .upload(caminho, arquivo, { upsert: true, cacheControl: '3600' })

    if (erroUpload) {
      setErroLogo('Não foi possível enviar a imagem. Tente novamente.')
      setEnviandoLogo(false)
      return
    }

    const { data } = supabase.storage.from('logos').getPublicUrl(caminho)
    // Adiciona um parâmetro para evitar cache de imagem antiga com o mesmo nome
    const urlComVersao = `${data.publicUrl}?v=${Date.now()}`

    atualizarCampo('logo_url', urlComVersao)
    setEnviandoLogo(false)
  }

  useEffect(() => {
    if (valores) setForm(valores)
  }, [valores])

  function atualizarCampo<K extends keyof EmpresaFormValues>(campo: K, valor: EmpresaFormValues[K]) {
    setForm((f) => (f ? { ...f, [campo]: valor } : f))
    setSucesso(false)
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!form) return
    setSalvando(true)
    const resultado = await salvar(form)
    setSalvando(false)
    if (!resultado) {
      setSucesso(true)
      // Reflete a cor primária imediatamente na interface
      document.documentElement.style.setProperty('--color-brand-500', form.cor_primaria)
    }
  }

  if (carregando || !form) {
    return <div className="h-64 animate-pulse rounded-lg bg-[var(--color-border)]/30" />
  }

  return (
    <Card>
      <CardContent className="pt-5">
        <form onSubmit={handleSubmit} className="max-w-2xl space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <Label htmlFor="nome">Nome da empresa</Label>
              <Input id="nome" value={form.nome} onChange={(e) => atualizarCampo('nome', e.target.value)} required />
            </div>
            <div>
              <Label htmlFor="cnpj">CNPJ</Label>
              <Input id="cnpj" value={form.cnpj} onChange={(e) => atualizarCampo('cnpj', e.target.value)} />
            </div>
            <div>
              <Label htmlFor="segmento">Segmento</Label>
              <Select id="segmento" value={form.segmento} onChange={(e) => atualizarCampo('segmento', e.target.value)}>
                {segmentos.map((s) => (
                  <option key={s.valor} value={s.valor}>
                    {s.rotulo}
                  </option>
                ))}
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="email">E-mail de contato</Label>
              <Input id="email" type="email" value={form.email} onChange={(e) => atualizarCampo('email', e.target.value)} />
            </div>
            <div>
              <Label htmlFor="telefone">Telefone</Label>
              <Input id="telefone" value={form.telefone} onChange={(e) => atualizarCampo('telefone', e.target.value)} />
            </div>
          </div>

          <div>
            <Label htmlFor="endereco">Endereço</Label>
            <Input id="endereco" value={form.endereco} onChange={(e) => atualizarCampo('endereco', e.target.value)} />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-2">
              <Label htmlFor="cidade">Cidade</Label>
              <Input id="cidade" value={form.cidade} onChange={(e) => atualizarCampo('cidade', e.target.value)} />
            </div>
            <div>
              <Label htmlFor="estado">Estado</Label>
              <Input
                id="estado"
                maxLength={2}
                value={form.estado}
                onChange={(e) => atualizarCampo('estado', e.target.value.toUpperCase())}
                placeholder="UF"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Logo da empresa</Label>
              <div className="flex items-center gap-3">
                {form.logo_url ? (
                  <img
                    src={form.logo_url}
                    alt="Logo"
                    className="h-12 w-12 rounded-md border border-[var(--color-border)] object-cover"
                  />
                ) : (
                  <div className="flex h-12 w-12 items-center justify-center rounded-md border border-dashed border-[var(--color-border)] text-[var(--color-ink-400)]">
                    <Upload className="h-4 w-4" />
                  </div>
                )}
                <input
                  ref={inputArquivoRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/svg+xml"
                  className="hidden"
                  onChange={handleUploadLogo}
                />
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={() => inputArquivoRef.current?.click()}
                  disabled={enviandoLogo}
                >
                  {enviandoLogo ? 'Enviando…' : 'Escolher imagem'}
                </Button>
              </div>
              {erroLogo && <p className="mt-1 text-xs text-danger-500">{erroLogo}</p>}
              <p className="mt-1 text-xs text-[var(--color-ink-400)]">PNG, JPG, WEBP ou SVG — até 2MB.</p>
            </div>
            <div>
              <Label htmlFor="cor_primaria">Cor da marca</Label>
              <div className="flex items-center gap-2">
                <input
                  id="cor_primaria"
                  type="color"
                  value={form.cor_primaria}
                  onChange={(e) => atualizarCampo('cor_primaria', e.target.value)}
                  className="h-9 w-11 rounded-md border border-[var(--color-border)] bg-transparent"
                />
                <Input value={form.cor_primaria} onChange={(e) => atualizarCampo('cor_primaria', e.target.value)} />
              </div>
            </div>
          </div>

          {linkAgendamento && (
            <div>
              <Label>Link de agendamento online</Label>
              <div className="flex items-center gap-2 rounded-md border border-[var(--color-border)] bg-[var(--color-canvas)] px-3 py-2">
                <span className="flex-1 truncate font-data text-sm text-[var(--color-ink-600)]">{linkAgendamento}</span>
                <Button type="button" variant="ghost" size="icon" onClick={copiarLink} aria-label="Copiar link">
                  {linkCopiado ? <Check className="h-4 w-4 text-success-500" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
              <p className="mt-1 text-xs text-[var(--color-ink-400)]">
                Compartilhe este link com seus clientes para que agendem sozinhos, sem precisar de login.
              </p>
            </div>
          )}

          {erro && <p className="rounded-md bg-danger-50 px-3 py-2 text-sm text-danger-500">{erro}</p>}
          {sucesso && <p className="rounded-md bg-success-50 px-3 py-2 text-sm text-success-500">Dados salvos com sucesso.</p>}

          <div className="flex justify-end pt-2">
            <Button type="submit" disabled={salvando}>
              {salvando ? 'Salvando…' : 'Salvar alterações'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
