import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from '@/context/AuthContext'
import { AppLayout } from '@/components/layout/app-layout'
import { ProtectedRoute } from '@/components/layout/protected-route'
import { LoginPage } from '@/pages/auth/login'
import { AgendamentoPublicoPage } from '@/pages/publico/agendar'
import { DashboardPage } from '@/pages/dashboard'
import { ClientesPage } from '@/pages/clientes'
import { AgendamentosPage } from '@/pages/agendamentos'
import { FinanceiroPage } from '@/pages/financeiro'
import { WhatsappPage } from '@/pages/whatsapp'
import { IaPage } from '@/pages/ia'
import { ConfiguracoesPage } from '@/pages/configuracoes'
import { PdvPage } from '@/pages/pdv'
import { SuperAdminEmpresasPage } from '@/pages/super-admin/empresas'

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/agendar/:slug" element={<AgendamentoPublicoPage />} />

          <Route
            element={
              <ProtectedRoute>
                <AppLayout />
              </ProtectedRoute>
            }
          >
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/clientes" element={<ClientesPage />} />
            <Route path="/agendamentos" element={<AgendamentosPage />} />
            <Route path="/pdv" element={<PdvPage />} />
            <Route
              path="/financeiro"
              element={
                <ProtectedRoute papeisPermitidos={['admin_empresa', 'super_admin']}>
                  <FinanceiroPage />
                </ProtectedRoute>
              }
            />
            <Route path="/whatsapp" element={<WhatsappPage />} />
            <Route
              path="/ia"
              element={
                <ProtectedRoute papeisPermitidos={['admin_empresa', 'super_admin']}>
                  <IaPage />
                </ProtectedRoute>
              }
            />
            <Route path="/configuracoes" element={<ConfiguracoesPage />} />
            <Route
              path="/super-admin/empresas"
              element={
                <ProtectedRoute papeisPermitidos={['super_admin']}>
                  <SuperAdminEmpresasPage />
                </ProtectedRoute>
              }
            />
          </Route>

          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  )
}
